/* Shared local presentation controls. No network requests or third-party dependencies. */
(() => {
  'use strict';
  const deck = document.querySelector('.deck');
  if (!deck) return;
  const slides = Array.from(deck.querySelectorAll(':scope > .slide'));
  if (!slides.length) return;
  const imageCredits = document.querySelector('.image-credits');
  const total = slides.length;
  const isEnglish = document.documentElement.lang.toLowerCase().startsWith('en');
  const t = isEnglish ? {
    slide: 'Slide', presentation: 'Presentation', controls: 'Presentation controls',
    previous: 'Previous slide', previousTitle: 'Previous ←', next: 'Next slide', nextTitle: 'Next →',
    progress: 'Presentation progress', openIndex: 'Open slide index', indexTitle: 'Index · I',
    openNotes: 'Open notes and sources', notesTitle: 'Notes and sources · N',
    fullscreen: 'Full screen', fullscreenTitle: 'Full screen · F', help: 'Help', helpTitle: 'Help · ?',
    close: 'Close', blackout: 'Black screen. Press B or Escape to return.',
    index: 'Slide index', notes: 'Notes', noNotes: 'This slide has no additional notes.',
    sources: 'Sources for this slide', howToNavigate: 'How to navigate',
    helpEntries: [
      ['→ / Space / Page Down', 'Next slide or next step'],
      ['← / Page Up', 'Previous slide'],
      ['Home / End', 'First / last slide'],
      ['I', 'Slide index'],
      ['N', 'Presenter notes and sources'],
      ['F', 'Full screen'],
      ['M', 'Turn motion on or off'],
      ['B', 'Black screen'],
      ['Esc', 'Close panel or black screen'],
      ['Mobile', 'Swipe left or right']
    ],
    slideRole: 'slide', of: 'of'
  } : {
    slide: 'Escena', presentation: 'Presentación', controls: 'Controles de la presentación',
    previous: 'Diapositiva anterior', previousTitle: 'Anterior ←', next: 'Diapositiva siguiente', nextTitle: 'Siguiente →',
    progress: 'Progreso de la presentación', openIndex: 'Abrir índice', indexTitle: 'Índice · I',
    openNotes: 'Abrir notas y fuentes', notesTitle: 'Notas y fuentes · N',
    fullscreen: 'Pantalla completa', fullscreenTitle: 'Pantalla completa · F', help: 'Ayuda', helpTitle: 'Ayuda · ?',
    close: 'Cerrar', blackout: 'Pantalla en negro. Pulse B o Escape para volver.',
    index: 'Índice', notes: 'Notas', noNotes: 'Esta escena no contiene notas adicionales.',
    sources: 'Fuentes de la escena', howToNavigate: 'Cómo navegar',
    helpEntries: [
      ['→ / Espacio / Av Pág', 'Siguiente escena o siguiente paso'],
      ['← / Re Pág', 'Escena anterior'],
      ['Inicio / Fin', 'Primera / última escena'],
      ['I', 'Índice de escenas'],
      ['N', 'Notas del ponente y fuentes'],
      ['F', 'Pantalla completa'],
      ['M', 'Activar o desactivar movimiento'],
      ['B', 'Pantalla en negro'],
      ['Esc', 'Cerrar panel o pantalla en negro'],
      ['Móvil', 'Deslizar a izquierda o derecha']
    ],
    slideRole: 'diapositiva', of: 'de'
  };
  let current = -1;
  let openPanel = null;
  let lastFocus = null;
  const chapterFor = slide => slide.dataset.chapter || slide.querySelector('.kicker')?.textContent?.trim() || '';
  const titleFor = (slide, index) => slide.dataset.title || slide.querySelector('.title,h1,h2')?.textContent?.trim().replace(/\s+/g, ' ') || `${t.slide} ${index + 1}`;
  const chrome = document.createElement('nav');
  chrome.className = 'deck-chrome';
  chrome.setAttribute('aria-label', t.controls);
  chrome.innerHTML = `
    <div class="deck-controls"><button type="button" data-deck-action="prev" aria-label="${t.previous}" title="${t.previousTitle}">‹</button><button type="button" data-deck-action="next" aria-label="${t.next}" title="${t.nextTitle}">›</button><span class="deck-counter" aria-live="polite"></span></div>
    <div class="deck-meta"><span class="deck-chapter"></span><div class="deck-progress" role="progressbar" aria-label="${t.progress}" aria-valuemin="1" aria-valuemax="${total}"><span></span></div></div>
    <div class="deck-menu"><button type="button" data-deck-action="index" aria-label="${t.openIndex}" title="${t.indexTitle}">☷</button><button type="button" data-deck-action="notes" aria-label="${t.openNotes}" title="${t.notesTitle}">✎</button><button type="button" data-deck-action="fullscreen" aria-label="${t.fullscreen}" title="${t.fullscreenTitle}">⛶</button><button type="button" data-deck-action="help" aria-label="${t.help}" title="${t.helpTitle}">?</button></div>`;
  const overlay = document.createElement('div');
  overlay.className = 'deck-overlay';
  overlay.setAttribute('aria-hidden', 'true');
  overlay.innerHTML = `<section class="deck-dialog" role="dialog" aria-modal="true" aria-labelledby="deck-dialog-title"><button class="deck-dialog-close" type="button" aria-label="${t.close}">×</button><h2 id="deck-dialog-title"></h2><div class="deck-dialog-body"></div></section>`;
  const blackout = document.createElement('div');
  blackout.className = 'blackout';
  blackout.setAttribute('aria-label', t.blackout);
  document.body.append(chrome, overlay, blackout);
  const counter = chrome.querySelector('.deck-counter');
  const chapter = chrome.querySelector('.deck-chapter');
  const progress = chrome.querySelector('.deck-progress');
  const progressFill = progress.querySelector('span');
  const dialogTitle = overlay.querySelector('#deck-dialog-title');
  const dialogBody = overlay.querySelector('.deck-dialog-body');
  const closeButton = overlay.querySelector('.deck-dialog-close');

  const hashIndex = () => {
    const raw = location.hash.slice(1);
    if (!/^\d+$/.test(raw)) return 0;
    return Math.min(total - 1, Math.max(0, Number(raw) - 1));
  };
  const pauseMedia = slide => slide?.querySelectorAll('video,audio').forEach(media => {
    try { media.pause(); } catch (_) { /* media may not be ready */ }
  });
  const syncTheme = slide => {
    chrome.classList.toggle('is-dark', slide.classList.contains('dark'));
    chrome.classList.toggle('is-orange', slide.classList.contains('section') || slide.classList.contains('orange'));
  };
  const syncIndex = () => {
    overlay.querySelectorAll('.deck-index-item').forEach((button, i) => button.setAttribute('aria-current', i === current ? 'true' : 'false'));
  };
  const go = (index, updateHash = true) => {
    const next = Math.min(total - 1, Math.max(0, index));
    if (next === current) {
      if (updateHash && location.hash !== `#${next + 1}`) location.hash = String(next + 1);
      return;
    }
    if (current >= 0) {
      const old = slides[current];
      pauseMedia(old);
      old.classList.remove('is-active', 'is-focus-mode');
      old.querySelectorAll('[data-focus].is-focused').forEach(el => el.classList.remove('is-focused'));
      old.setAttribute('aria-hidden', 'true');
    }
    current = next;
    const slide = slides[current];
    slide.classList.add('is-active');
    slide.setAttribute('aria-hidden', 'false');
    slide.scrollTop = 0;
    counter.textContent = `${String(current + 1).padStart(2, '0')} / ${String(total).padStart(2, '0')}`;
    chapter.textContent = chapterFor(slide);
    progress.setAttribute('aria-valuenow', String(current + 1));
    progressFill.style.width = `${((current + 1) / total) * 100}%`;
    syncTheme(slide);
    syncIndex();
    document.title = `${titleFor(slide, current)} · ${document.body.dataset.deckTitle || t.presentation}`;
    if (updateHash && location.hash !== `#${current + 1}`) location.hash = String(current + 1);
    if (openPanel === 'notes') renderNotes();
    document.dispatchEvent(new CustomEvent('deck:change', { detail: { index: current, number: current + 1, slide } }));
  };
  const setStepState = (element, revealed) => {
    element.classList.toggle('is-revealed', revealed);
    element.setAttribute('aria-hidden', revealed ? 'false' : 'true');
    if ('inert' in element) element.inert = !revealed;
    const targetSelector = element.dataset.revealTarget;
    if (targetSelector) {
      document.querySelectorAll(targetSelector).forEach(target => target.classList.toggle('is-linked-revealed', revealed));
    }
    if (!revealed) element.querySelectorAll('video,audio').forEach(media => { try { media.pause(); } catch (_) {} });
  };
  const revealStep = () => {
    const hidden = slides[current]?.querySelector('[data-step]:not(.is-revealed)');
    if (!hidden) return false;
    setStepState(hidden, true);
    hidden.dispatchEvent(new CustomEvent('deck:reveal', { bubbles: true }));
    return true;
  };
  const next = () => { if (!revealStep()) go(current + 1); };
  const prev = () => {
    const revealed = Array.from(slides[current]?.querySelectorAll('[data-step].is-revealed') || []);
    if (revealed.length) { setStepState(revealed[revealed.length - 1], false); return; }
    go(current - 1);
  };
  const close = () => {
    if (!openPanel) return;
    overlay.classList.remove('is-open');
    overlay.setAttribute('aria-hidden', 'true');
    dialogBody.replaceChildren();
    openPanel = null;
    lastFocus?.focus?.();
  };
  const open = (type, title) => {
    if (openPanel === type) { close(); return; }
    lastFocus = document.activeElement;
    openPanel = type;
    dialogTitle.textContent = title;
    dialogBody.replaceChildren();
    overlay.classList.add('is-open');
    overlay.setAttribute('aria-hidden', 'false');
    closeButton.focus();
  };
  const renderIndex = () => {
    open('index', t.index);
    if (openPanel !== 'index') return;
    const grid = document.createElement('div');
    grid.className = 'deck-index-grid';
    slides.forEach((slide, i) => {
      const item = document.createElement('button');
      item.type = 'button';
      item.className = 'deck-index-item';
      item.dataset.index = String(i);
      item.setAttribute('aria-current', i === current ? 'true' : 'false');
      const number = document.createElement('small'); number.textContent = String(i + 1).padStart(2, '0');
      const title = document.createElement('strong'); title.textContent = titleFor(slide, i);
      const chapter = document.createElement('em'); chapter.textContent = chapterFor(slide);
      item.append(number, title, chapter);
      grid.append(item);
    });
    dialogBody.append(grid);
  };
  const renderNotes = () => {
    if (openPanel !== 'notes') { open('notes', t.notes); if (openPanel !== 'notes') return; }
    dialogTitle.textContent = `${t.notes} · ${String(current + 1).padStart(2, '0')} / ${String(total).padStart(2, '0')}`;
    dialogBody.replaceChildren();
    const wrapper = document.createElement('div');
    wrapper.className = 'deck-notes-content';
    const heading = document.createElement('h3');
    heading.textContent = titleFor(slides[current], current);
    wrapper.append(heading);
    const template = slides[current].querySelector('template.presenter,template.speaker-notes,template.notes');
    if (template) wrapper.append(template.content.cloneNode(true));
    else {
      const message = document.createElement('p');
      message.textContent = t.noNotes;
      wrapper.append(message);
    }
    const sourceLinks = Array.from(slides[current].querySelectorAll('.source a[href]'));
    const existingUrls = new Set(Array.from(wrapper.querySelectorAll('a[href]')).map(a => a.href));
    const extra = sourceLinks.filter(a => !existingUrls.has(a.href));
    if (extra.length) {
      const list = document.createElement('div'); list.className = 'source-list';
      const h = document.createElement('h3'); h.textContent = t.sources; list.append(h);
      extra.forEach(a => { const p = document.createElement('p'); p.append(a.cloneNode(true)); list.append(p); });
      wrapper.append(list);
    }
    wrapper.querySelectorAll('a[href^="http"]').forEach(a => { a.target = '_blank'; a.rel = 'noopener noreferrer'; });
    dialogBody.append(wrapper);
  };
  const renderHelp = () => {
    open('help', t.howToNavigate);
    if (openPanel !== 'help') return;
    const dl = document.createElement('dl'); dl.className = 'deck-help-grid';
    t.helpEntries.forEach(([key, description]) => { const dt = document.createElement('dt'); const dd = document.createElement('dd'); dt.textContent = key; dd.textContent = description; dl.append(dt, dd); });
    dialogBody.append(dl);
  };
  const toggleFullscreen = () => {
    if (document.fullscreenElement) document.exitFullscreen?.();
    else document.documentElement.requestFullscreen?.().catch(() => {});
  };
  const toggleBlackout = () => {
    blackout.classList.toggle('is-open');
    blackout.setAttribute('aria-hidden', blackout.classList.contains('is-open') ? 'false' : 'true');
  };
  const runAction = action => {
    if (action === 'prev') prev();
    else if (action === 'next') next();
    else if (action === 'index') renderIndex();
    else if (action === 'notes') renderNotes();
    else if (action === 'help') renderHelp();
    else if (action === 'fullscreen') toggleFullscreen();
  };
  chrome.addEventListener('click', event => {
    const button = event.target.closest('[data-deck-action]');
    if (button) runAction(button.dataset.deckAction);
  });
  overlay.addEventListener('click', event => {
    if (event.target === overlay || event.target.closest('.deck-dialog-close')) { close(); return; }
    const indexButton = event.target.closest('.deck-index-item');
    if (indexButton) { close(); go(Number(indexButton.dataset.index)); }
  });
  blackout.addEventListener('click', toggleBlackout);
  deck.addEventListener('click', event => {
    const stepButton = event.target.closest('[data-step-next]');
    if (stepButton) { revealStep(); return; }
    const focus = event.target.closest('[data-focus]');
    if (!focus || !slides[current]?.contains(focus)) return;
    const slide = slides[current];
    const active = focus.classList.contains('is-focused');
    slide.querySelectorAll('[data-focus].is-focused').forEach(el => el.classList.remove('is-focused'));
    slide.classList.toggle('is-focus-mode', !active);
    if (!active) focus.classList.add('is-focused');
  });
  document.addEventListener('keydown', event => {
    const key = event.key;
    if (blackout.classList.contains('is-open')) {
      if (key === 'Escape' || key.toLowerCase() === 'b') { event.preventDefault(); toggleBlackout(); }
      return;
    }
    if (key === 'Escape') {
      if (imageCredits?.open) {
        event.preventDefault();
        imageCredits.open = false;
        imageCredits.querySelector('summary')?.focus();
      }
      else if (openPanel) { event.preventDefault(); close(); }
      else if (slides[current]?.classList.contains('is-focus-mode')) {
        slides[current].classList.remove('is-focus-mode');
        slides[current].querySelectorAll('.is-focused').forEach(el => el.classList.remove('is-focused'));
      }
      return;
    }
    const target = event.target;
    if (imageCredits?.open || target?.closest?.('.image-credits')) return;
    if (target?.closest?.('input,textarea,select,[contenteditable="true"]')) return;
    if (openPanel) {
      if (key.toLowerCase() === 'i' && openPanel === 'index') { event.preventDefault(); close(); }
      if (key.toLowerCase() === 'n' && openPanel === 'notes') { event.preventDefault(); close(); }
      return;
    }
    if (target?.closest?.('video,audio,iframe')) return;
    if (['ArrowRight', 'ArrowDown', 'PageDown', ' ', 'Enter'].includes(key) && !(key === 'Enter' && target?.closest?.('button,a'))) { event.preventDefault(); next(); }
    else if (['ArrowLeft', 'ArrowUp', 'PageUp', 'Backspace'].includes(key)) { event.preventDefault(); prev(); }
    else if (key === 'Home') { event.preventDefault(); go(0); }
    else if (key === 'End') { event.preventDefault(); go(total - 1); }
    else if (key.toLowerCase() === 'i') { event.preventDefault(); renderIndex(); }
    else if (key.toLowerCase() === 'n') { event.preventDefault(); renderNotes(); }
    else if (key.toLowerCase() === 'f') { event.preventDefault(); toggleFullscreen(); }
    else if (key.toLowerCase() === 'm') { event.preventDefault(); document.body.classList.toggle('reduce-motion'); }
    else if (key.toLowerCase() === 'b') { event.preventDefault(); toggleBlackout(); }
    else if (key === '?' || (key === '/' && event.shiftKey)) { event.preventDefault(); renderHelp(); }
  });
  let touchStart = null;
  deck.addEventListener('touchstart', event => {
    if (event.touches.length !== 1) return;
    const touch = event.touches[0];
    touchStart = { x: touch.clientX, y: touch.clientY, target: event.target };
  }, { passive: true });
  deck.addEventListener('touchend', event => {
    if (!touchStart || event.changedTouches.length !== 1) return;
    const touch = event.changedTouches[0];
    const dx = touch.clientX - touchStart.x;
    const dy = touch.clientY - touchStart.y;
    const isInteractive = touchStart.target.closest?.('a,button,video,iframe,input,textarea,select,[data-focus],.scroll-x');
    if (!isInteractive && Math.abs(dx) > 65 && Math.abs(dx) > Math.abs(dy) * 1.35) dx < 0 ? next() : prev();
    touchStart = null;
  }, { passive: true });
  window.addEventListener('hashchange', () => go(hashIndex(), false));
  slides.forEach((slide, i) => {
    slide.setAttribute('aria-roledescription', t.slideRole);
    slide.setAttribute('aria-label', `${i + 1} ${t.of} ${total}: ${titleFor(slide, i)}`);
    slide.setAttribute('aria-hidden', 'true');
    slide.querySelectorAll('[data-step]').forEach(element => setStepState(element, false));
  });
  document.body.classList.add('deck-ready');
  go(hashIndex(), false);
  if (!/^#\d+$/.test(location.hash)) history.replaceState(null, '', `${location.pathname}${location.search}#1`);
  window.PresentationDeck = Object.freeze({ go: number => go(number - 1), next, prev, get current() { return current + 1; }, get total() { return total; } });
})();
