(() => {
  'use strict';

  document.querySelectorAll('img[data-fallback]').forEach(image => {
    image.addEventListener('error', () => {
      if (image.dataset.fallback && image.getAttribute('src') !== image.dataset.fallback) {
        image.src = image.dataset.fallback;
      }
    }, { once: true });
  });

  const tabs = Array.from(document.querySelectorAll('.service-tabs [role="tab"]'));
  const panels = Array.from(document.querySelectorAll('.service-panel[role="tabpanel"]'));
  if (!tabs.length || !panels.length) return;

  function selectService(tab, moveFocus = false) {
    const name = tab.dataset.service;
    tabs.forEach(item => {
      const active = item === tab;
      item.setAttribute('aria-selected', String(active));
      item.tabIndex = active ? 0 : -1;
    });
    panels.forEach(panel => {
      const active = panel.dataset.servicePanel === name;
      panel.hidden = !active;
      panel.classList.toggle('is-current', active);
    });
    if (moveFocus) tab.focus();
  }

  tabs.forEach((tab, index) => {
    tab.tabIndex = index === 0 ? 0 : -1;
    tab.addEventListener('click', () => selectService(tab));
  });

  document.querySelector('.service-tabs')?.addEventListener('keydown', event => {
    if (!['ArrowRight', 'ArrowLeft', 'ArrowDown', 'ArrowUp', 'Home', 'End'].includes(event.key)) return;
    const index = tabs.indexOf(document.activeElement);
    if (index < 0) return;
    event.preventDefault();
    event.stopPropagation();
    let next = index;
    if (event.key === 'ArrowRight' || event.key === 'ArrowDown') next = (index + 1) % tabs.length;
    else if (event.key === 'ArrowLeft' || event.key === 'ArrowUp') next = (index - 1 + tabs.length) % tabs.length;
    else if (event.key === 'Home') next = 0;
    else if (event.key === 'End') next = tabs.length - 1;
    selectService(tabs[next], true);
  });
})();
